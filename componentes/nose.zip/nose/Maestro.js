import React from "react";
import { View, StyleSheet,Text } from 'react-native';
import Iterando from "./Iterando";
class Maestro extends React.Component{
  state={
      data:[]
  }
  async componentDidMount(){
      await this.cargarComponentes()
  }
  cargarComponentes=async()=>{
      try {
          let res = await fetch('http://192.168.20.45:8000/api/info');
          let data = await res.json();
          console.log(data); // Verifica los datos aquí
          this.setState({
              data
          });
      } catch (error) {
          console.error(error);
      }
  }
  render(){
      return (
          <View style={styles.container}>
              <Text>Lista de Imágenes</Text>
              <Iterando variableIterable={this.state.data} />
          </View>
      );
  }
}

const styles = StyleSheet.create({
container: {
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center',
  padding: 16,
},
});

export default Maestro;
