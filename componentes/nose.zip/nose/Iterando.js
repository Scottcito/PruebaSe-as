import React from 'react';
import { View} from 'react-native';
import ComponenteImage from './ComponenteImage';

const Iterando = ({ variableIterable }) => (
  <View> 
    {variableIterable.map((variableIterable) => (   
      <ComponenteImage
        key={variableIterable.Id_Imagen}
        Image_Palabra={variableIterable.Image_Palabra}
        PalabrasId_Palabra={variableIterable.PalabrasId_Palabra}

      />
    ))}
  </View>
);

export default Iterando;
